* timeap.js 扩展文件
* demo.sb3 demo 作品
* icon.png 图标
* cover.png 封面
* info.json

我修改了 scratch-render的webglrender的drawthese方法（在src/override.js中）
。可能需要修改，在src/override.js所有我修改的都标注了by:nights，否则骨骼，图层管理，雷神，可能无法与tilemap一起使用

这个是打包好了的，没打包的：[https://github.com/Nightre/tilemap](https://github.com/Nightre/tilemap)