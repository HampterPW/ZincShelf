# install
```
npm i
```

# build
```
npm run build
```

# 扩展文件在dist\stats.js